# RALLY COPILOT GPS — prototype Android

Projet natif Kotlin de démarrage. Il reçoit du texte partagé depuis Google Maps,
géocode les adresses avec OpenStreetMap/Nominatim, calcule un trajet avec OSRM,
affiche la route sur une carte Leaflet/OpenStreetMap et annonce les manœuvres
à proximité via la synthèse vocale Android.

## Compiler l'APK
1. Installer Android Studio sur un ordinateur.
2. Ouvrir ce dossier dans Android Studio et laisser Gradle se synchroniser.
3. Brancher un téléphone Android ou créer un émulateur.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK debug sera dans `app/build/outputs/apk/debug/`.

## Utiliser
Dans Google Maps : destination > Partager > choisir RALLY COPILOT GPS.
Autoriser la localisation, attendre le GPS, puis générer le roadbook.

## Limites à connaître
Ceci est un prototype fonctionnel de départ, pas une application de navigation certifiée.
Les niveaux de virage 1/3/5 sont une approximation à partir des instructions de route OSRM,
pas une mesure du rayon réel ni de la difficulté du virage. L'anticipation GPS doit être
testée et améliorée avant tout usage réel. Les services publics Nominatim/OSRM ont des
conditions d'utilisation et limites de débit ; prévoir des services adaptés pour diffusion.
La carte nécessite Internet. Tester à l'arrêt et ne pas manipuler le téléphone en conduisant.
