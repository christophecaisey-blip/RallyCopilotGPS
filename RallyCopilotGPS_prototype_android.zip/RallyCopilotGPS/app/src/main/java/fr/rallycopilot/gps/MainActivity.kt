package fr.rallycopilot.gps

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.speech.tts.TextToSpeech
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class MainActivity : Activity(), LocationListener {
    private lateinit var destination: EditText
    private lateinit var status: TextView
    private lateinit var note: TextView
    private lateinit var distance: TextView
    private lateinit var map: WebView
    private lateinit var lm: LocationManager
    private var tts: TextToSpeech? = null
    private var notes = mutableListOf<PaceNote>()
    private var nextNote = 0
    private var announced = -1

    data class PaceNote(val lat: Double, val lon: Double, val text: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,24,32)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16,16,16,10); setBackgroundColor(Color.rgb(16,24,32))
        }
        root.addView(TextView(this).apply {
            text = "🏁 RALLY COPILOT GPS"; textSize = 22f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        destination = EditText(this).apply {
            hint = "Destination ou adresse"; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(destination)
        root.addView(Button(this).apply {
            text = "GÉNÉRER LE ROADBOOK"
            setOnClickListener { buildRoute(destination.text.toString()) }
        })
        status = TextView(this).apply {
            text = "Partage une destination Google Maps ou saisis une adresse."
            setTextColor(Color.LTGRAY)
        }
        root.addView(status)
        note = TextView(this).apply {
            text = "EN ATTENTE"; textSize = 32f
            setTextColor(Color.rgb(255,201,40)); gravity = Gravity.CENTER
            setPadding(0,12,0,4)
        }
        root.addView(note)
        distance = TextView(this).apply {
            text = "—"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        root.addView(distance)
        root.addView(Button(this).apply {
            text = "▶ LIRE LA PROCHAINE NOTE"
            setOnClickListener { readNext() }
        })
        map = WebView(this).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadDataWithBaseURL("https://localhost/", mapHtml(), "text/html", "UTF-8", null)
        }
        root.addView(map, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        acceptShare(intent)
    }

    private fun acceptShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") {
            destination.setText(i.getStringExtra(Intent.EXTRA_TEXT).orEmpty())
            status.text = "Destination reçue. Appuie sur Générer."
        }
    }

    private fun coords(text: String): Pair<Double,Double>? {
        val match = Regex("""(-?\d{1,3}\.\d+)\s*,\s*(-?\d{1,3}\.\d+)""").find(text) ?: return null
        val a = match.groupValues[1].toDoubleOrNull() ?: return null
        val b = match.groupValues[2].toDoubleOrNull() ?: return null
        return if (abs(a) <= 90 && abs(b) <= 180) Pair(a,b) else null
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "RallyCopilotGPS/0.1")
        return c.inputStream.bufferedReader().use { it.readText() }.also { c.disconnect() }
    }

    private fun geocode(q: String): Pair<Double,Double>? {
        coords(q)?.let { return it }
        val data = get("https://nominatim.openstreetmap.org/search?q=${URLEncoder.encode(q,"UTF-8")}&format=json&limit=1")
        val arr = org.json.JSONArray(data)
        if (arr.length() == 0) return null
        return Pair(arr.getJSONObject(0).getString("lat").toDouble(), arr.getJSONObject(0).getString("lon").toDouble())
    }

    private fun buildRoute(q: String) {
        if (q.isBlank()) { status.text = "Saisis une destination."; return }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 5)
            status.text = "Autorise la localisation puis appuie à nouveau sur Générer."
            return
        }
        status.text = "Calcul de l'itinéraire…"
        thread {
            try {
                val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ?: throw Exception("Position GPS indisponible. Attends le premier fix GPS.")
                val dest = geocode(q) ?: throw Exception("Destination introuvable")
                val routeUrl = "https://router.project-osrm.org/route/v1/driving/${loc.longitude},${loc.latitude};${dest.second},${dest.first}?overview=full&geometries=geojson&steps=true"
                val routeRoot = JSONObject(get(routeUrl))
                if (routeRoot.optString("code") != "Ok") throw Exception("Itinéraire introuvable")
                val route = routeRoot.getJSONArray("routes").getJSONObject(0)
                val generated = mutableListOf<PaceNote>()
                val steps = route.getJSONArray("legs").getJSONObject(0).getJSONArray("steps")
                for (i in 0 until steps.length()) {
                    val s = steps.getJSONObject(i)
                    val m = s.getJSONObject("maneuver")
                    val type = m.optString("type")
                    val mod = m.optString("modifier")
                    val word = when {
                        mod.contains("left") -> "GAUCHE"
                        mod.contains("right") -> "DROITE"
                        mod == "uturn" -> "ÉPINGLe"
                        type == "roundabout" -> "ROND-POINT"
                        type == "arrive" -> "ARRIVÉE"
                        type == "fork" -> "EMBRANCHEMENT"
                        type == "continue" || type == "new name" -> "TOUT DROIT"
                        else -> ""
                    }
                    if (word.isNotBlank() && type != "depart") {
                        val grade = when (mod) {
                            "sharp left","sharp right" -> "1"
                            "left","right" -> "3"
                            "slight left","slight right" -> "5"
                            else -> ""
                        }
                        val p = m.getJSONArray("location")
                        generated.add(PaceNote(p.getDouble(1),p.getDouble(0), if (grade.isBlank()) word else "$word $grade"))
                    }
                }
                val geom = route.getJSONObject("geometry").getJSONArray("coordinates")
                val pts = (0 until geom.length()).map { val p=geom.getJSONArray(it); "[${p.getDouble(1)},${p.getDouble(0)}]" }
                runOnUiThread {
                    notes = generated; nextNote = 0; announced = -1
                    status.text = "Roadbook prêt • ${"%.1f".format(route.optDouble("distance")/1000)} km • ${notes.size} notes"
                    note.text = notes.firstOrNull()?.text ?: "AUCUNE NOTE"
                    map.evaluateJavascript("drawRoute([${pts.joinToString(",")}]);", null)
                    startGps()
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Erreur : ${e.message}" } }
        }
    }

    private fun startGps() {
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000L,5f,this) }
        catch (_: Exception) { status.text = "Activation GPS impossible." }
    }

    override fun onLocationChanged(loc: Location) {
        if (nextNote >= notes.size) return
        val n = notes[nextNote]
        val target = Location("note").apply { latitude=n.lat; longitude=n.lon }
        val meters = loc.distanceTo(target)
        runOnUiThread {
            distance.text = "PROCHAINE NOTE • ${meters.toInt()} m"
            if (meters < 350 && announced != nextNote) {
                announced = nextNote
                tts?.speak("Dans ${meters.toInt()} mètres, ${n.text}",TextToSpeech.QUEUE_ADD,null,"note$nextNote")
                note.text = n.text
                nextNote++
            }
        }
    }

    private fun readNext() {
        if (notes.isEmpty()) return
        val i = nextNote.coerceAtMost(notes.lastIndex)
        note.text = notes[i].text
        tts?.speak(notes[i].text,TextToSpeech.QUEUE_FLUSH,null,"manual$i")
    }

    private fun mapHtml() = """
    <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>html,body,#map{height:100%;margin:0;background:#101820}</style>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script></head>
    <body><div id="map"></div><script>
    const map=L.map('map').setView([46.6,2.4],6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
    function drawRoute(points){const line=L.polyline(points,{color:'#ffc928',weight:5}).addTo(map);map.fitBounds(line.getBounds(),{padding:[20,20]});}
    </script></body></html>
    """.trimIndent()

    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); setIntent(intent); acceptShare(intent) }
    override fun onRequestPermissionsResult(r: Int,p: Array<out String>,g: IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if (r==5) status.text = "Autorisation reçue. Appuie sur Générer."
    }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    override fun onStatusChanged(provider: String?, state: Int, extras: Bundle?) {}
    override fun onDestroy() { lm.removeUpdates(this); tts?.shutdown(); super.onDestroy() }
}
