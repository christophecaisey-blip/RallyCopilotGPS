plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "fr.rallycopilot.gps"
    compileSdk = 35
    defaultConfig {
        applicationId = "fr.rallycopilot.gps"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
